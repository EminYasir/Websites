/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SocialMedia;

import java.util.Date;

/**
 *
 * @author emin yasir corut
 */
public class Message extends Text {

    private User fromUser;
    private User toUser;
    private long dateNumber;

    public Message(User fromUser, User toUser, String text) {
        this.fromUser = fromUser;
        this.toUser = toUser;
        this.setText(text);
        this.dateNumber = getDateSort();
    }

    public User getFromUser() {
        return fromUser;
    }

    public void setFromUser(User fromUser) {
        this.fromUser = fromUser;
    }

    public User getToUser() {
        return toUser;
    }

    public void setToUser(User toUser) {
        this.toUser = toUser;
    }

    public long getDateNumber() {
        return dateNumber;
    }

    public void setDateNumber(long dateNumber) {
        this.dateNumber = dateNumber;
    }

    public long getDateSort() {
        int i = (int) (new Date().getTime() / 1000);
        return i;
    }
}
