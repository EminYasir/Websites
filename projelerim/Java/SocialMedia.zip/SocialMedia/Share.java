/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SocialMedia;

/**
 *
 * @author emin yasir corut
 */
public class Share extends Text {

    private User[] likeList;
    private Comment[] commentList;
    protected int likeCount;
    protected int commentCount;

    public Share(String text) {
        this.setText(text);
        this.likeList = new User[100];
        this.commentList = new Comment[100];
    }

    public User[] getLikeList() {
        return likeList;
    }

    public void setLikeList(User[] likeList) {
        this.likeList = likeList;
    }

    public Comment[] getCommentList() {
        return commentList;
    }

    public void setCommentList(Comment[] CommentList) {
        this.commentList = CommentList;
    }

    public void Like(User user) {
        for (int i = 0; i < likeList.length; i++) {
            if (likeList[i] == null) {
                likeList[i] = user;
                break;
            }
        }
    }

    public void AddComment(Comment comment) {
        for (int i = 0; i < commentList.length; i++) {
            if (commentList[i] == null) {
                commentList[i] = comment;
                break;
            }
        }
    }

    public int getLikeCount() {
        likeCount = 0;

        for (int i = 0; i < likeList.length; i++) {
            if (likeList[i] != null) {
                likeCount++;
            }
        }

        return likeCount;
    }

    public int getCommentCount() {
        commentCount = 0;

        for (int i = 0; i < commentList.length; i++) {
            if (commentList[i] != null) {
                commentCount++;
            }
        }

        return commentCount;
    }

    public void DeleteComment(Comment comment) {
        Boolean isDeleted = false;
        for (int i = 0; i < commentList.length; i++) {
            if (commentList[i] == comment) {
                commentList[i] = null;
                isDeleted = true;
                break;
            }
        }

        if (!isDeleted) {
            System.out.println("Silinecek yorum bulunamadı.");
        }
    }

    public void ListComment() {
        int commentCount = 0;
        for (int i = 0; i < commentList.length; i++) {
            if (commentList[i] != null) {
                commentCount++;
            }
        }
        System.out.println("Yorum Sayısı : " + commentCount);

        System.out.println("Yorum Listesi");
        int index = 1;
        for (int i = 0; i < commentList.length; i++) {
            if (commentList[i] != null) {
                System.out.println(index + ". Yorum : " + commentList[i].getText());
                System.out.println(index + ". Yorum Yapan Kişi : " + commentList[i].getUser().getName());

                index++;
            }
        }
    }
}
