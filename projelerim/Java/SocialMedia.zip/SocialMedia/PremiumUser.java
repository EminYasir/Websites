/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SocialMedia;

/**
 *
 * @author emin yasir corut
 */
public class PremiumUser extends User {
    
    public PremiumUser(int id, String name) {
        super(id, name);
    }

    @Override
    public Boolean HasAccessFriendShareList(User user) {
        return true;
    }
}
