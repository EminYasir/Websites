/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SocialMedia;

import java.util.Scanner;

/**
 * @file SocialMedia
 * @description Küçük çaplı sosyal medya uygulaması
 * @assignment 3.Ödev
 * @date 27.01.2021
 * @author emin yasir corut && eminyasir.corut@stu.fsm.edu.tr
 * 
 */
public class AppTest {

    public static void main(String[] args) {

        PremiumUser Murat = new PremiumUser(1, "Murat Baran(1)");
        PremiumUser Emin = new PremiumUser(2, "Emin Corut(2)");
        PremiumUser Seyit = new PremiumUser(3, "Seyit Özel(3)");
        PremiumUser Sevgi = new PremiumUser(4, "Sevgi Bilir(4)");
        PremiumUser Emirhan = new PremiumUser(5, "Emirhan Bilgin(5)");
        StandardUser Yavuz = new StandardUser(6, "Yavuz Yıldız(6)");
        StandardUser Mahmut = new StandardUser(7, "Mahmut Kuş(7)");
        StandardUser Eda = new StandardUser(8, "Musa Kaya(8)");
        StandardUser Ali = new StandardUser(9, "Ali Yolcu(9)");
        StandardUser Eren = new StandardUser(10, "Eren Çağrı(10)");

        User[] user = {Murat, Emin, Seyit, Sevgi, Emirhan, Yavuz, Mahmut, Eda, Ali, Eren};

        Emin.SendRequestFriend(Murat);
        Eren.SendRequestFriend(Murat);
        Sevgi.SendRequestFriend(Murat);
        Emin.SendRequestFriend(Murat);
        Yavuz.SendRequestFriend(Murat);
        Sevgi.SendRequestFriend(Ali);
        Yavuz.SendRequestFriend(Ali);
        Eren.SendRequestFriend(Mahmut);
        Yavuz.SendRequestFriend(Mahmut);

        Murat.AcceptRequestFriend(Eren);
        Murat.AcceptRequestFriend(Sevgi);
        Mahmut.AcceptRequestFriend(Eren);
        Ali.AcceptRequestFriend(Sevgi);
        Ali.AcceptRequestFriend(Yavuz);
        Murat.AcceptRequestFriend(Yavuz);

        System.out.println("          ------>             Sosyal medya Uygulamasına hoşgeldiniz            <-------                ");
        Scanner sc = new Scanner(System.in);
        boolean choose = true;
        boolean isChooseTrue = true;
        String a = "0";
        while (choose) {
            System.out.println("     Menü tablosu       ");
            System.out.println("1-Kullanıcı seçimi\n"
                    + "2-Programı sonlandırma");
            System.out.println("Ne yapmak istiyorsun");
            System.out.print("Seçim = ");
            while (isChooseTrue) {
                a = sc.nextLine();
                if ("1".equals(a) || "2".equals(a)) {
                    isChooseTrue = false;

                } else {
                    System.out.print("Hatalı seçim Lütfen tekrar deneyiniz= ");
                    isChooseTrue = true;
                }
            }
            if ("1".equals(a)) {
                UserSelection(user);
                isChooseTrue = true;
            } else if ("2".equals(a)) {
                System.out.println("Program sonlandırılmıştır.");
                isChooseTrue = false;
                choose = false;
            }

        }
    }

    public static void UserSelection(User[] user) {
        Scanner sc = new Scanner(System.in);
        boolean isIdTrue = true;
        String number_s = "";
        System.out.println("     Kullanıcılar ve Id ");
        System.out.println("Murat-1\n"
                + "Emin-2\n"
                + "Seyit-3\n"
                + "Sevgi-4\n"
                + "Emirhan-5\n"
                + "Yavuz-6\n"
                + "Mahmut-7\n"
                + "Eda-8\n"
                + "Ali-9\n"
                + "Eren-10"
        );
        System.out.print("Lütfen kullanıcının id numaranısı giriniz= ");

        while (isIdTrue) {
            number_s = sc.next();
            if ("1".equals(number_s) || "2".equals(number_s) || "3".equals(number_s) || "4".equals(number_s) || "5".equals(number_s) || "6".equals(number_s) || "7".equals(number_s) || "8".equals(number_s) || "9".equals(number_s) || "10".equals(number_s)) {
                isIdTrue = false;

            } else {
                System.out.print("Hatalı id Lütfen tekrar deneyiniz= ");
                isIdTrue = true;

            }
        }
        int number_i = Integer.parseInt(number_s);

        switch (number_i) {
            case 1:
                System.out.println("Merhaba Murat Baran");
                Uygulama(number_i, user);
                break;
            case 2:
                System.out.println("Merhaba Emin Corut");
                Uygulama(number_i, user);
                break;
            case 3:
                System.out.println("Merhaba Seyit Özel");
                Uygulama(number_i, user);
                break;
            case 4:
                System.out.println("Merhaba Sevgi Bilir");
                Uygulama(number_i, user);
                break;
            case 5:
                System.out.println("Merhaba Emirhan Bilgin");
                Uygulama(number_i, user);
                break;
            case 6:
                System.out.println("Merhaba Yavuz Yıldız");
                Uygulama(number_i, user);
                break;
            case 7:
                System.out.println("Merhaba Mahmut Kuş");
                Uygulama(number_i, user);
                break;
            case 8:
                System.out.println("Merhaba Eda Kaya");
                Uygulama(number_i, user);
                break;
            case 9:
                System.out.println("Merhaba Ali Yolcu");
                Uygulama(number_i, user);
                break;
            case 10:
                System.out.println("Merhaba Eren Çağrı");
                Uygulama(number_i, user);
                break;
        }
    }

    public static void Uygulama(int a, User[] user) {
        Share share1 = new Share("");
        Share share2 = new Share("");
        Share share3 = new Share("");
        Share share4 = new Share("");
        Share share5 = new Share("");
        Share share6 = new Share("");
        Share share7 = new Share("");
        Share share8 = new Share("");
        Share share9 = new Share("");
        Share share10 = new Share("");

        Share[] arrayofShare = {share1, share2, share3, share4, share5, share6, share7, share8, share9, share10};

        User userEmpty = null;

        Comment comment1 = new Comment("", userEmpty);
        Comment comment2 = new Comment("", userEmpty);
        Comment comment3 = new Comment("", userEmpty);
        Comment comment4 = new Comment("", userEmpty);
        Comment comment5 = new Comment("", userEmpty);
        Comment comment6 = new Comment("", userEmpty);
        Comment comment7 = new Comment("", userEmpty);
        Comment comment8 = new Comment("", userEmpty);
        Comment comment9 = new Comment("", userEmpty);
        Comment comment10 = new Comment("", userEmpty);

        Comment[] arrayofComment = {comment1, comment2, comment3, comment4, comment5, comment6, comment7, comment8, comment9, comment10};

        boolean y = true;
        String personShare = null;
        String UptadeShare = null;
        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);
        Scanner vc = new Scanner(System.in);
        boolean isHasPost = true;
        String t = "";
        System.out.println("*******Uygulama Menüsü*****");
        System.out.println("1-Arkadaşlarımı listele\n"
                + "2-Arkadaş sil\n"
                + "3-Arkadaşlık isteği gönder\n"
                + "4-Arkadaşlık isteği bekleyenleri listele \n"
                + "5-Arkadaşlık isteği kabul et\n"
                + "6-Paylaşım yap\n"
                + "7-Paylaşım güncelle\n"
                + "8-Paylaşım sil\n"
                + "9-Paylaşımlarını listele\n"
                + "10-Arkadaşının paylaşımlarını listele\n"
                + "11-Arkadaşının paylaşımını beğen\n"
                + "12-Arkadaşının paylaşımına yorum yap\n"
                + "13-yorum sil\n"
                + "14-Yorumlarını listele\n"
                + "15-En çok beğeni alan paylaşımını listele\n"
                + "16-En az beğeni alan paylaşımı listele\n"
                + "17-En çok yorum alan paylaşımını listele\n"
                + "18-En az yorum alan paylaşımını listele\n"
                + "19-Yorumlarda numara payalaşan kişileri listele\n"
                + "20-Arkadaşına mesaj at\n"
                + "21-Arkadaşlarınla mesajlaşmalarını listele\n"
                + "22-Ana menüye dön"
        );
        System.out.println("**************************");
        while (y) {

            System.out.print("Yapmak istediğiniz seçimi belirleyiniz= ");
            Boolean isIdTrue = true;
            String num = "";
            String choosing = sc1.nextLine();
            int postNumber = 0;
            switch (choosing) {

                case "1":
                    user[a - 1].ListFriends();
                    break;
                case "2":
                    user[a - 1].ListFriends();
                    System.out.print("Arkadaşlık listesinden silmek istediğiniz kişinin id numarasını giriniz= ");
                    while (isIdTrue) {
                        num = sc.next();
                        if ("1".equals(num) || "2".equals(num) || "3".equals(num) || "4".equals(num) || "5".equals(num) || "6".equals(num) || "7".equals(num) || "8".equals(num) || "9".equals(num) || "10".equals(num)) {
                            isIdTrue = false;
                            break;

                        } else {
                            System.out.print("Hatalı id Lütfen tekrar deneyiniz= ");
                            isIdTrue = true;

                        }
                    }
                    int number_i = Integer.parseInt(num);

                    user[a - 1].DeleteFriend(user[number_i - 1]);
                    break;
                case "3":
                    System.out.print("Arkadaşlık isteği göndermek istediğiniz kişinin id numarasını giriniz= ");
                    while (isIdTrue) {
                        num = sc.next();
                        if ("1".equals(num) || "2".equals(num) || "3".equals(num) || "4".equals(num) || "5".equals(num) || "6".equals(num) || "7".equals(num) || "8".equals(num) || "9".equals(num) || "10".equals(num)) {
                            isIdTrue = false;
                            break;

                        } else {
                            System.out.print("Hatalı id Lütfen tekrar deneyiniz= ");
                            isIdTrue = true;

                        }
                    }
                    number_i = Integer.parseInt(num);
                    user[a - 1].SendRequestFriend(user[number_i - 1]);
                    System.out.println("********************************");
                    break;
                case "4":
                    user[a - 1].ListRequestFriends();
                    break;
                case "5":
                    user[a - 1].ListRequestFriends();
                    System.out.print("Kabul etmek istediğiniz kişinin id numarasını giriniz= ");
                    while (isIdTrue) {
                        num = sc.next();
                        if ("1".equals(num) || "2".equals(num) || "3".equals(num) || "4".equals(num) || "5".equals(num) || "6".equals(num) || "7".equals(num) || "8".equals(num) || "9".equals(num) || "10".equals(num)) {
                            isIdTrue = false;
                            break;

                        } else {
                            System.out.print("Hatalı id Lütfen tekrar deneyiniz= ");
                            isIdTrue = true;

                        }
                    }
                    number_i = Integer.parseInt(num);
                    user[a - 1].AcceptRequestFriend(user[number_i - 1]);
                    System.out.println("********************************");
                    break;
                case "6":
                    System.out.print("Paylaşım içeriğinizi giriniz= ");
                    personShare = vc.nextLine();
                    for (int i = 0; i < arrayofShare.length; i++) {
                        if (arrayofShare[i].getText() == "") {
                            arrayofShare[i].setText(personShare);
                            user[a - 1].InsertShare(arrayofShare[i]);
                            break;
                        }
                    }

                    System.out.println("********************************");
                    break;
                case "7":
                    user[a - 1].ListShare();
                    System.out.print("kaçıncı paylaşımınızı güncellemek istiyorsunuz= ");
                    while (isHasPost) {
                        t = sc.nextLine();
                        for (int i = 0; i < t.length(); i++) {
                            if (t.charAt(i) >= '0' && t.charAt(i) <= '9') {
                                isHasPost = false;
                            } else {
                                isHasPost = true;
                                System.out.print("Hatalı input tekrar giriniz= ");
                                break;
                            }
                        }
                        if (!isHasPost) {
                            postNumber = Integer.parseInt(t);

                            if (postNumber > user[a - 1].getShareList().length) {
                                System.out.print("Hatalı input tekrar giriniz= ");
                                isHasPost = true;
                            }
                        }
                    }

                    isHasPost = true;
                    System.out.print("yeni paylaşım içeriğini giriniz= ");
                    UptadeShare = sc.nextLine();

                    user[a - 1].UpdateShare(user[a - 1].getShareList()[postNumber - 1], UptadeShare);
                    System.out.println("********************************");
                    break;
                case "8":
                    user[a - 1].ListShare();
                    System.out.print("kaçıncı paylaşımınızı silmek istiyorsunuz= ");
                    while (isHasPost) {
                        t = vc.nextLine();
                        for (int i = 0; i < t.length(); i++) {
                            if (t.charAt(i) >= '0' && t.charAt(i) <= '9') {
                                isHasPost = false;
                            } else {
                                isHasPost = true;
                                System.out.print("Hatalı input tekrar giriniz= ");
                                break;
                            }

                        }
                        if (!isHasPost) {
                            postNumber = Integer.parseInt(t);

                            if (postNumber > user[a - 1].getShareList().length) {
                                System.out.print("Hatalı input tekrar giriniz= ");
                                isHasPost = true;
                            }
                        }
                    }
                    isHasPost = true;

                    user[a - 1].DeleteShare(user[a - 1].getShareList()[postNumber - 1]);
                    System.out.println("*******************************");
                    break;
                case "9":
                    user[a - 1].ListShare();
                    System.out.println("********************************");
                    break;
                case "10":
                    System.out.print("paylaşımlarını listelemek istediğiniz arkadşınızın id sini giriniz= ");
                    boolean n = true;
                    while (n) {
                        while (isIdTrue) {
                            num = sc.next();
                            if ("1".equals(num) || "2".equals(num) || "3".equals(num) || "4".equals(num) || "5".equals(num) || "6".equals(num) || "7".equals(num) || "8".equals(num) || "9".equals(num) || "10".equals(num)) {
                                isIdTrue = false;
                                break;
                            } else {
                                System.out.print("Hatalı id Lütfen tekrar deneyiniz= ");
                                isIdTrue = true;
                            }
                        }
                        number_i = Integer.parseInt(num);
                        for (int i = 0; i < user.length; i++) {
                            if (user[i].equals(user[number_i - 1])) {
                                user[a - 1].ListFriendShare(user[number_i - 1]);
                                n = false;
                                System.out.println("*******************************");
                                break;
                            }
                        }
                        if (n == true) {
                            System.out.print("Hatalı id tekrar giriniz= ");
                        }
                    }
                    break;
                case "11":
                    System.out.println("paylaşımını beğenmek istediğiniz arkadaşınızın id sini giriniz= ");
                    n = true;
                    while (n) {
                        while (isIdTrue) {
                            num = sc.next();
                            if ("1".equals(num) || "2".equals(num) || "3".equals(num) || "4".equals(num) || "5".equals(num) || "6".equals(num) || "7".equals(num) || "8".equals(num) || "9".equals(num) || "10".equals(num)) {
                                isIdTrue = false;
                                break;
                            } else {
                                System.out.print("Hatalı id Lütfen tekrar deneyiniz= ");
                                isIdTrue = true;
                            }
                        }
                        number_i = Integer.parseInt(num);
                        
                        Boolean isFriend = true;
                        for (int i = 0; i < user[number_i].getFriendList().length; i++) {
                            if (user[a - 1].getFriendList()[i] != null && user[a - 1].getFriendList()[i].equals(user[number_i-1])) {
                                isFriend = false;
                            }
                        }
                        if (isFriend) {
                            System.out.println("Kişi arkadaşlarınızda bulunamadı.");
                            break;
                        }
                        
                        for (int i = 0; i < user.length; i++) {
                            if (user[i].equals(user[number_i - 1])) {
                                user[number_i - 1].ListShare();
                                System.out.print("Kaçıncı postu beğenmek istiyorsunuz= ");
                                while (isHasPost) {
                                    t = sc.nextLine();
                                    for (int j = 0; j < t.length(); j++) {

                                        if (t.charAt(j) >= '0' && t.charAt(j) <= '9') {
                                            isHasPost = false;
                                        } else {
                                            isHasPost = true;
                                            System.out.print("Hatalı input tekrar giriniz= ");
                                            break;
                                        }
                                    }
                                }
                                isHasPost = true;
                                postNumber = Integer.parseInt(t);
                                user[number_i - 1].getShareList()[postNumber - 1].Like(user[a - 1]);
                                n = false;
                                System.out.println("*******************************");
                                break;
                            }
                        }
                        if (n == true) {
                            System.out.print("Hatalı id tekrar giriniz= ");
                        }
                    }
                    break;
                case "12":
                    System.out.print("paylaşımını yorum eklemek istediğiniz arkadaşınızın id sini giriniz= ");
                    n = true;
                    while (n) {
                        while (isIdTrue) {
                            num = sc.next();
                            if ("1".equals(num) || "2".equals(num) || "3".equals(num) || "4".equals(num) || "5".equals(num) || "6".equals(num) || "7".equals(num) || "8".equals(num) || "9".equals(num) || "10".equals(num)) {
                                isIdTrue = false;
                                break;

                            } else {
                                System.out.print("Hatalı id Lütfen tekrar deneyiniz= ");
                                isIdTrue = true;
                            }
                        }
                        number_i = Integer.parseInt(num);

                        Boolean isFriend = true;
                        for (int i = 0; i < user[number_i].getFriendList().length; i++) {
                            if (user[a - 1].getFriendList()[i] != null && user[a - 1].getFriendList()[i].equals(user[number_i-1])) {
                                isFriend = false;
                            }
                        }
                        if (isFriend) {
                            System.out.println("Kişi arkadaşlarınızda bulunamadı.");
                            break;
                        }
                        for (int i = 0; i < user.length; i++) {
                            if (user[i].equals(user[number_i - 1])) {
                                user[number_i - 1].ListShare();
                                System.out.print("Kaçıncı posta yorum eklemek istiyorsunuz= ");
                                while (isHasPost) {
                                    t = sc.nextLine();
                                    for (int j = 0; j < t.length(); j++) {

                                        if (t.charAt(j) > '0' && t.charAt(j) <= '9') {
                                            isHasPost = false;
                                        } else {
                                            isHasPost = true;
                                            System.out.print("Hatalı input tekrar giriniz= ");
                                            break;
                                        }
                                    }
                                }
                                isHasPost = true;
                                postNumber = Integer.parseInt(t);
                                System.out.print("Yorum içeriğinizi giriniz= ");
                                personShare = vc.nextLine();
                                for (int j = 0; j < arrayofShare.length; j++) {
                                    if (arrayofComment[j].getText() == "") {
                                        arrayofComment[j].setText(personShare);
                                        arrayofComment[j].setUser(user[a - 1]);
                                        user[number_i - 1].getShareList()[postNumber - 1].AddComment(arrayofComment[j]);
                                        n = false;
                                        System.out.println("***********************");
                                        break;
                                    }
                                }
                                break;
                            }
                        }
                        if (n == true) {
                            System.out.print("Hatalı id tekrar giriniz= ");
                        }
                    }
                    break;
                case "13":
                    System.out.print("yorum silmek  istediğiniz paylaşıma sahip arkadaşınızın id sini giriniz= ");
                    n = true;
                    while (n) {
                        while (isIdTrue) {
                            num = sc.next();
                            if ("1".equals(num) || "2".equals(num) || "3".equals(num) || "4".equals(num) || "5".equals(num) || "6".equals(num) || "7".equals(num) || "8".equals(num) || "9".equals(num) || "10".equals(num)) {
                                isIdTrue = false;
                                break;
                            } else {
                                System.out.print("Hatalı id Lütfen tekrar deneyiniz= ");
                                isIdTrue = true;
                            }
                        }
                        number_i = Integer.parseInt(num);
                        for (int i = 0; i < user.length; i++) {
                            if (user[i].equals(user[number_i - 1])) {
                                user[number_i - 1].ListShare();
                                System.out.print("Kaçıncı postaki yorumu silmek istiyorsunuz= ");
                                while (isHasPost) {
                                    t = sc.nextLine();
                                    for (int j = 0; j < t.length(); j++) {
                                        if (t.charAt(j) > '0' && t.charAt(j) <= '9') {
                                            isHasPost = false;
                                        } else {
                                            isHasPost = true;
                                            System.out.print("Hatalı input tekrar giriniz= ");
                                        }
                                    }
                                }
                                isHasPost = true;
                                postNumber = Integer.parseInt(t);
                                System.out.println("Posttaki hangi yorumu silmek istiyorsunuz");
                                int p = sc.nextInt();
                                for (int l = 0; l < arrayofShare.length; l++) {
                                    if (arrayofComment[l].getText() != null) {
                                        arrayofComment[l].setText("");
                                        user[number_i - 1].getShareList()[postNumber - 1].DeleteComment(arrayofComment[p - 1]);
                                        n = false;
                                        break;
                                    }
                                }
                                break;
                            }
                        }
                        if (n == true) {
                            System.out.print("Hatalı id tekrar giriniz= ");
                        }
                    }
                    break;
                case "14":
                    user[a-1].ListShare();
                    System.out.print("Kaçıncı postunuzun yorumlarını listelemek istiyorsunuz= ");
                    while (isIdTrue) {
                        num = sc.next();
                        if ("1".equals(num) || "2".equals(num) || "3".equals(num) || "4".equals(num) || "5".equals(num) || "6".equals(num) || "7".equals(num) || "8".equals(num) || "9".equals(num) || "10".equals(num)) {
                            isIdTrue = false;
                            break;
                        } else {
                            System.out.print("Hatalı id Lütfen tekrar deneyiniz= ");
                            isIdTrue = true;
                        }
                    }
                    number_i = Integer.parseInt(num);
                    user[a - 1].getShareList()[number_i - 1].ListComment();
                    break;
                case "15":
                    user[a - 1].WriteMostCountLike();
                    System.out.println("**************************");
                    break;
                case "16":
                    user[a - 1].WriteLeastCountLike();
                    System.out.println("**************************");

                    break;
                case "17":
                    user[a - 1].WriteMostCountComment();
                    System.out.println("**************************");

                    break;
                case "18":
                    user[a - 1].WriteLeastCountComment();
                    System.out.println("**************************");

                    break;
                case "19":
                    user[a - 1].GetCommentContainPhoneNumber();
                    System.out.println("**************************");
                    break;
                case "20":
                    System.out.println("mesaj göndermek istediğiniz arkadaşınızın id sini giriniz= ");
                    n = true;
                    while (n) {
                        while (isIdTrue) {
                            num = sc.next();
                            if ("1".equals(num) || "2".equals(num) || "3".equals(num) || "4".equals(num) || "5".equals(num) || "6".equals(num) || "7".equals(num) || "8".equals(num) || "9".equals(num) || "10".equals(num)) {
                                isIdTrue = false;
                                break;
                            } else {
                                System.out.print("Hatalı id Lütfen tekrar deneyiniz= ");
                                isIdTrue = true;
                            }
                        }
                        number_i = Integer.parseInt(num);
                        System.out.print("Mesaj içeriğini giriniz= ");
                        String message = sc2.nextLine();
                        n = false;
                        user[a - 1].SendMessage(user[number_i - 1], message);
                    }
                    break;
                case "21":
                    System.out.print("sohbet içeriğini görmek istediğiniz arkadaşınızın id sini giriniz= ");
                    while (isIdTrue) {
                        num = sc.next();
                        if ("1".equals(num) || "2".equals(num) || "3".equals(num) || "4".equals(num) || "5".equals(num) || "6".equals(num) || "7".equals(num) || "8".equals(num) || "9".equals(num) || "10".equals(num)) {
                            isIdTrue = false;
                            break;
                        } else {
                            System.out.print("Hatalı id Lütfen tekrar deneyiniz= ");
                            isIdTrue = true;
                        }
                    }
                    number_i = Integer.parseInt(num);
                    user[a - 1].ListMessage(user[number_i - 1]);
                    break;
                case "22":
                    y = false;
                    break;

            }
        }
    }
}
