/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SocialMedia;

/**
 *
 * @author emin yasir corut
 */
public class StandardUser extends User {
    
    public StandardUser(int id, String name) {
        super(id, name);
    }

    @Override
    public Boolean HasAccessFriendShareList(User user) {
        Boolean isFriend = false;
        for (int i = 0; i < this.getFriendList().length; i++) {
            if (this.getFriendList()[i] == user) {
                isFriend = true;
            }
        }

        if (!isFriend) {
            return false;
        }
        
        return true;
    }
    
}
