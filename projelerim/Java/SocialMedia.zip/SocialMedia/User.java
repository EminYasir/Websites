/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SocialMedia;

import Proje3.Kullanici;

/**
 *
 * @author emin yasir corut
 */
public abstract class User {

    private int id;
    private String name;
    private User[] friendList;
    private User[] requestFriendList;
    private Share[] shareList;
    private Message[] messageInbox;
    private Message[] messageOutbox;

    public User(int id, String name) {
        this.id = id;
        this.name = name;
        this.friendList = new User[10];
        this.requestFriendList = new User[10];
        this.shareList = new Share[20];
        this.messageInbox = new Message[20];
        this.messageOutbox = new Message[20];
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public User[] getFriendList() {
        return friendList;
    }

    public void setFriendList(User[] friendList) {
        this.friendList = friendList;
    }

    public User[] getRequestFriendList() {
        return requestFriendList;
    }

    public void setRequestFriendList(User[] RequestFriendList) {
        this.requestFriendList = RequestFriendList;
    }

    public Share[] getShareList() {
        return shareList;
    }

    public void setShareList(Share[] shareList) {
        this.shareList = shareList;
    }

    public Message[] getMessageInbox() {
        return messageInbox;
    }

    public void setMessageInbox(Message[] messageInbox) {
        this.messageInbox = messageInbox;
    }

    public Message[] getMessageOutbox() {
        return messageOutbox;
    }

    public void setMessageOutbox(Message[] messageOutbox) {
        this.messageOutbox = messageOutbox;
    }

    public void ListFriends() {
        if (friendList != null && friendList.length > 0) {
            int index = 1;
            System.out.println(this.name + " Kişisinin Arkadaş Listesi");
            for (int i = 0; i < friendList.length; i++) {
                if (friendList[i] != null) {
                    System.out.println(index + ". " + friendList[i].getName());
                    index++;
                }
            }
        }
    }

    public void DeleteFriend(User user) {
        Boolean isDeleted = false;

        for (int i = 0; i < friendList.length; i++) {

            if (friendList[i] == user) {
                System.out.println(friendList[i].getName() + " arkadaşınız arkadaşlıktan silindi");
                friendList[i] = null;
                isDeleted = true;

                break;
            }
        }

        if (!isDeleted) {
            System.out.println("Silinecek kişi arkadaş listenizde mevcut değildir.");
        }
    }

    public void SendRequestFriend(User user) {
        try {
            Boolean isAdded = false;
            for (int i = 0; i < user.requestFriendList.length; i++) {
                if (user.requestFriendList[i] == null) {
                    user.requestFriendList[i] = this;
                    isAdded = true;
                    System.out.println("arkadaşlık isteği gönderildi");
                    break;
                }
            }

            if (!isAdded) {
                System.out.println("Arkadaşlık isteğiniz liste dolduğu için alınamadı.");
            }
        } catch (NullPointerException ex) {
        }
    }

    public void AcceptRequestFriend(User user) {
        Boolean isFullMyFriendList = true;
        Boolean isFullSendedFriendList = true;

        for (int i = 0; i < this.friendList.length; i++) {
            if (this.friendList[i] == null) {
                isFullMyFriendList = false;
            }
        }

        for (int i = 0; i < user.friendList.length; i++) {
            if (user.friendList[i] == null) {
                isFullSendedFriendList = false;
            }
        }

        if (isFullMyFriendList || isFullSendedFriendList) {
            System.out.println("Arkadaşlık listesi dolu olduğu için istek kabul edilemedi.");
            return;
        }

        for (int i = 0; i < requestFriendList.length; i++) {
            if (requestFriendList[i] == user) {
                for (int j = 0; j < friendList.length; j++) {
                    if (friendList[j] == null) {
                        friendList[j] = user;
                        System.out.println("Kişi arkadaşlık listesine eklendi");
                        requestFriendList[i] = null;
                        break;
                    }
                }
            }
        }

        for (int i = 0; i < user.friendList.length; i++) {
            if (user.friendList[i] == null) {
                user.friendList[i] = this;
                break;
            }
        }
    }

    public void ListRequestFriends() {
        if (requestFriendList != null && requestFriendList.length > 0) {
            int index = 1;
            System.out.println(this.name + " Kişisinin  Arkadaşlık isteği Listesi");
            for (int i = 0; i < requestFriendList.length; i++) {
                if (requestFriendList[i] != null) {
                    System.out.println(index + ". " + requestFriendList[i].getName());
                    index++;
                }
            }
        }
    }

    public void InsertShare(Share share) {
        Boolean isShared = false;

        for (int i = 0; i < shareList.length; i++) {
            if (shareList[i] == null) {
                shareList[i] = share;
                isShared = true;
                System.out.println("Paylaşım yapıldı");
                break;
            }
        }

        if (!isShared) {
            System.out.println("Paylaşım listeniz dolu olduğu için paylaşım yapamıyorsunuz.");
        }
    }

    public void UpdateShare(Share share, String text) {
        Boolean updatedShared = false;

        for (int i = 0; i < shareList.length; i++) {
            if (shareList[i] == share) {
                shareList[i].setText(text);
                updatedShared = true;
                System.out.println("payaşım güncellenmiştir");
                break;
            }
        }

        for (int i = 0; i < shareList.length; i++) {
            for (int j = 1; j < shareList.length; j++) {
                if (shareList[i] == null && shareList[j] != null) {
                    Share temp = shareList[j];
                    shareList[i] = temp;
                    shareList[j] = null;
                    temp = null;
                }
            }
        }

        if (!updatedShared) {
            System.out.println("Güncellemek istediğiniz paylaşım listenizde bulunamadı.");
        }
    }

    public void DeleteShare(Share share) {
        if (share == null) {
            System.out.println("Silinecek paylaşım yoktur.");
            return;
        }

        Boolean isDeleted = false;

        for (int i = 0; i < shareList.length; i++) {
            if (shareList[i] == share) {
                shareList[i] = null;
                isDeleted = true;
                System.out.println("paylaşımınız silinmiştir");
                break;
            }
        }

        for (int i = 0; i < shareList.length; i++) {
            for (int j = 1; j < shareList.length; j++) {
                if (shareList[i] == null && shareList[j] != null) {
                    Share temp = shareList[j];
                    shareList[i] = temp;
                    shareList[j] = null;
                    temp = null;
                }
            }
        }

        if (!isDeleted) {
            System.out.println("Silinecek paylaşım bulunamadı.");
        }
    }

    public void ListShare() {
        if (shareList[0] == null) {
            System.out.println(" Kişisinin Paylaşım Listesi Boştur.");
            return;
        }

        System.out.println(this.name + " Kişisinin Paylaşım Listesi");
        int index = 1;
        for (int i = 0; i < shareList.length; i++) {
            if (shareList[i] != null) {

                System.out.println(index + ". Paylaşım : " + shareList[i].getText());
                index++;

                int likeCount = 0;
                for (int j = 0; j < shareList[i].getLikeList().length; j++) {
                    if (shareList[i].getLikeList()[j] != null) {
                        likeCount++;
                    }
                }
                System.out.println("Paylaşımın Beğeni Sayısı : " + likeCount);
                if (likeCount > 0) {
                    System.out.println("Paylaşımı Beğenen Kişiler");
                }

                int likeIndex = 1;
                for (int j = 0; j < shareList[i].getLikeList().length; j++) {
                    if (shareList[i].getLikeList()[j] != null) {
                        System.out.println(likeIndex + ". " + shareList[i].getLikeList()[j].getName());
                        likeIndex++;
                    }
                }
                int commentCount = 0;
                for (int j = 0; j < shareList[i].getCommentList().length; j++) {
                    if (shareList[i].getCommentList()[j] != null) {
                        commentCount++;
                    }
                }
                System.out.println("Paylaşımın Yorum Sayısı : " + commentCount);
                if (commentCount > 0) {
                    System.out.println("Paylaşıma yorum yapan Kişiler");
                }

                int commentIndex = 1;
                for (int j = 0; j < shareList[i].getCommentList().length; j++) {
                    if (shareList[i].getCommentList()[j] != null) {
                        System.out.println(commentIndex + ". " + shareList[i].getCommentList()[j].getUser().getName());
                        System.out.print("Yorum içeriği= ");
                        System.out.println(shareList[i].getCommentList()[j].getText());
                        commentIndex++;
                    }
                }

            }
        }
    }

    public abstract Boolean HasAccessFriendShareList(User user);

    public void ListFriendShare(User user) {

        Boolean hasAccess = HasAccessFriendShareList(user);

        if (!hasAccess) {
            System.out.println(user.name + " adlı kişi arkadaşınız olmadığı için paylaşımlarını görüntüleyemezsiniz. Lütfen paylaşımlarını görüntülemek istiyorsanız hesabınızı premium a yükseltiniz.");
            return;
        }

        System.out.println(user.name + " Kişisinin Paylaşım Listesi");
        int index = 1;
        for (int i = 0; i < user.getShareList().length; i++) {
            if (user.getShareList()[i] != null) {

                System.out.println(index + ". Paylaşım : " + user.getShareList()[i].getText());
                index++;

                int likeCount = 0;
                for (int j = 0; j < user.getShareList()[i].getLikeList().length; j++) {
                    if (user.getShareList()[i].getLikeList()[j] != null) {
                        likeCount++;
                    }
                }
                System.out.println("Paylaşımın Beğeni Sayısı : " + likeCount);
                if (likeCount > 0) {
                    System.out.println("Paylaşımı Beğenen Kişiler");
                }

                int likeIndex = 1;
                for (int j = 0; j < user.getShareList()[i].getLikeList().length; j++) {
                    if (user.getShareList()[i].getLikeList()[j] != null) {
                        System.out.println(likeIndex + ". " + user.getShareList()[i].getLikeList()[j].name);
                        likeIndex++;
                    }
                }
            }
        }
    }

    public void WriteMostCountLike() {
        int mostCount = 0;
        int index = 0;
        for (int i = 0; i < shareList.length; i++) {
            if (shareList[i] != null && shareList[i].getLikeCount() > mostCount) {
                mostCount = shareList[i].getLikeCount();
                index = i;
            }
        }

        System.out.println("En çok beğeni alan paylaşım.");
        System.out.println("Beğeni adedi :" + shareList[index].likeCount);
        System.out.println("Paylaşım :" + shareList[index].getText());
    }

    public void WriteLeastCountLike() {
        int leastCount = 0;
        int index = 0;
        for (int i = 0; i < shareList.length; i++) {
            if (shareList[i] != null && shareList[i].getLikeCount() <= leastCount) {
                leastCount = shareList[i].getLikeCount();
                index = i;
            }
        }

        System.out.println("En az beğeni alan paylaşım.");
        System.out.println("Beğeni adedi :" + shareList[index].likeCount);
        System.out.println("Paylaşım :" + shareList[index].getText());
    }

    public void WriteMostCountComment() {
        int mostCount = 0;
        int index = 0;
        for (int i = 0; i < shareList.length; i++) {
            if (shareList[i] != null && shareList[i].getCommentCount() > mostCount) {
                mostCount = shareList[i].getCommentCount();
                index = i;
            }
        }

        System.out.println("En çok yorum alan paylaşım.");
        System.out.println("Yorum adedi :" + shareList[index].commentCount);
        System.out.println("Paylaşım :" + shareList[index].getText());
    }

    public void WriteLeastCountComment() {
        int leastCount = 0;
        int index = 0;
        for (int i = 0; i < shareList.length; i++) {
            if (shareList[i] != null && shareList[i].getCommentCount() <= leastCount) {
                leastCount = shareList[i].getCommentCount();
                index = i;
            }
        }

        System.out.println("En az yorum alan paylaşım.");
        System.out.println("Yorum adedi :" + shareList[index].commentCount);
        System.out.println("Paylaşım :" + shareList[index].getText());
    }

    public void SendMessage(User toUser, String text) {
        Boolean isFriend = false;
        Boolean isFullInbox = true;
        Boolean isFullOutbox = true;
        Message message = new Message(this, toUser, text);

        for (int i = 0; i < friendList.length; i++) {
            if (friendList[i] == toUser) {
                isFriend = true;

                for (int j = 0; j < this.messageOutbox.length; j++) {
                    if (this.messageOutbox[j] == null) {
                        isFullOutbox = false;
                    }
                    if (toUser.messageInbox[j] == null) {
                        isFullInbox = false;
                    }
                }

                if (isFullInbox || isFullOutbox) {
                    if (isFullInbox) {
                        System.out.println("Mesaj göndermek istediğiniz kullanıcının mesaj kutusu dolu olduğu için mesajınız gönderilemedi.");
                    } else if (isFullOutbox) {
                        System.out.println("Mesaj gönderi kutunuz dolu olduğu için mesajınız gönderilemedi.");
                    }

                    return;
                }

                for (int j = 0; j < toUser.messageInbox.length; j++) {
                    if (toUser.messageInbox[j] == null) {
                        toUser.messageInbox[j] = message;
                        break;
                    }
                }

                for (int j = 0; j < this.messageOutbox.length; j++) {
                    if (this.messageOutbox[j] == null) {
                        this.messageOutbox[j] = message;
                        break;
                    }
                }

                System.out.println("Mesajınız gönderildi.");
            }
        }

        if (!isFriend) {
            System.out.println("Mesaj göndermek istediğiniz kullanıcı arkadaşınız olmadığı için mesaj gönderemezsiniz.");
        }
    }

    public void ListMessage(User fromUser) {
        Message[] messageList = new Message[40];
        int index = 0;

        for (int i = 0; i < this.messageInbox.length; i++) {
            if (this.messageInbox[i] != null && this.messageInbox[i].getFromUser() == fromUser) {
                messageList[index] = this.messageInbox[i];
                index++;
            }
        }

        for (int i = 0; i < this.messageOutbox.length; i++) {
            if (this.messageOutbox[i] != null && this.messageOutbox[i].getToUser() == fromUser) {
                messageList[index] = this.messageOutbox[i];
                index++;
            }
        }

        for (int i = 0; i < messageList.length; i++) {
            for (int j = i + 1; j < messageList.length; j++) {
                if (messageList[i] != null && messageList[j] != null) {
                    if (messageList[i].getDateNumber() > messageList[j].getDateNumber()) {
                        Message temp = messageList[i];
                        messageList[i] = messageList[j];
                        messageList[j] = temp;
                    }
                }

            }
        }

        for (int i = 0; i < messageList.length; i++) {
            if (messageList[i] != null) {
                System.out.println("Gönderen : " + messageList[i].getFromUser().getName() + ", Alıcı : " + messageList[i].getToUser().getName() + ", Mesaj : " + messageList[i].getText());
            }
        }
    }

    public void GetCommentContainPhoneNumber() {
        Boolean isNumber = true;

        for (int i = 0; i < this.shareList.length; i++) {
            if (this.shareList[i] != null) {
                for (int j = 0; j < this.shareList[i].getCommentList().length; j++) {
                    if (this.shareList[i].getCommentList()[j] != null) {
                        String a[] = this.shareList[i].getCommentList()[j].getText().split(" ");
                        for (int m = 0; m < a.length; m++) {

                            if (a[m].length() == 11) {
                                for (int k = 0; k < a[m].length(); k++) {
                                    if (a[m].charAt(i) >= '0' && a[m].charAt(i) <= '9') {
                                        continue;
                                    } else {
                                        isNumber = false;
                                        break;
                                    }
                                }
                                if (isNumber) {
                                    System.out.println(this.shareList[i].getCommentList()[j].getUser().name);
                                }
                            }
                        }
                    }
                }
            }

        }
    }
}
